-- Kalendarz Rodzinny: wydarzenia współdzielone w istniejących gospodarstwach Zakupy Razem.
-- Uruchom w tym samym projekcie Supabase, w którym są households i household_members.

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 100),
  event_date date not null,
  event_time time,
  notes text not null default '' check (char_length(notes) <= 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_calendar_events_household_date
  on public.calendar_events(household_id, event_date, event_time);

alter table public.calendar_events enable row level security;

drop policy if exists "Household members can read calendar events" on public.calendar_events;
create policy "Household members can read calendar events"
  on public.calendar_events for select to authenticated
  using (public.is_household_member(household_id));

drop policy if exists "Household members can add calendar events" on public.calendar_events;
create policy "Household members can add calendar events"
  on public.calendar_events for insert to authenticated
  with check (
    public.is_household_member(household_id)
    and created_by = (select auth.uid())
  );

drop policy if exists "Household members can edit calendar events" on public.calendar_events;
create policy "Household members can edit calendar events"
  on public.calendar_events for update to authenticated
  using (public.is_household_member(household_id))
  with check (public.is_household_member(household_id));

drop policy if exists "Household members can delete calendar events" on public.calendar_events;
create policy "Household members can delete calendar events"
  on public.calendar_events for delete to authenticated
  using (public.is_household_member(household_id));

grant select, insert, update, delete on public.calendar_events to authenticated;

-- Supabase Realtime: bez tego zapisy będą widoczne po odświeżeniu, ale nie na żywo.
do $$ begin
  alter publication supabase_realtime add table public.calendar_events;
exception when duplicate_object then null;
end $$;

notify pgrst, 'reload schema';
