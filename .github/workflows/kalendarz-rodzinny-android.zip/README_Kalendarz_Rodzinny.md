# Kalendarz Rodzinny — Android

## Zbuduj testowy APK bez Android Studio

1. Rozpakuj pakiet `Kalendarz_Rodzinny_Android_Pakiet.zip` do repozytorium GitHub. W katalogu głównym powinny być pliki `kalendarz-rodzinny-android.zip` i folder `.github/workflows`.
2. W GitHub otwórz kartę **Actions**, wybierz **Kalendarz Rodzinny — zbuduj APK** i kliknij **Run workflow**. Możesz też uruchomić budowanie przez push.
3. Po zakończeniu pobierz artefakt **Kalendarz-Rodzinny-APK**, rozpakuj go i zainstaluj `app-debug.apk` na telefonach.

## Podłącz do „Zakupy Razem”

1. W tym samym projekcie Supabase co „Zakupy Razem” uruchom `database/calendar_events.sql` w SQL Editorze.
2. W Supabase → **Authentication → URL Configuration → Redirect URLs** dodaj dokładnie: `kalendarzrodzinny://auth/callback`.
3. Na każdym telefonie otwórz ⚙ i wpisz ten sam **Project URL** oraz publiczny klucz **anon/publishable** używany przez „Zakupy Razem”. Nigdy nie używaj `service_role`.
4. Zaloguj się kontem Google używanym w grupie „Zakupy Razem”. Jeśli oboje jesteście już członkami tego gospodarstwa, kalendarz pobierze je automatycznie. Wydarzenia będą się synchronizować na żywo.

Jeśli żona nie jest jeszcze członkiem gospodarstwa, dołącz ją wcześniej w „Zakupy Razem” albo użyj kodu zaproszenia do grupy.

## Co zawiera pakiet

- `kalendarz-rodzinny-android.zip` — projekt Android i zasoby aplikacji.
- `.github/workflows/build-calendar-apk.yml` — workflow budujący APK testowe.
- `database/calendar_events.sql` — migracja tabeli wydarzeń współdzielonych.

Do przygotowania APK nie jest wymagane Android Studio. APK z workflow jest wersją debug do testów; nie jest podpisanym pakietem do Google Play.
