-- Kalendarz Rodzinny: dodanie cyklicznosci do istniejacej bazy.
-- Uruchom tylko w projekcie Supabase Kalendarza Rodzinnego.
-- Zachowuje wszystkie zapisane wydarzenia; dotychczasowe pozostaja jednorazowe.

alter table public.calendar_events add column if not exists recurrence_type text not null default 'none';
alter table public.calendar_events add column if not exists recurrence_interval integer not null default 1;
alter table public.calendar_events add column if not exists recurrence_days integer[] not null default '{}';
alter table public.calendar_events add column if not exists recurrence_until date;
alter table public.calendar_events add column if not exists occasion_type text not null default 'none';

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'calendar_events_occasion_type_check') then
    alter table public.calendar_events add constraint calendar_events_occasion_type_check
      check (occasion_type in ('none','birthday','name_day'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'calendar_events_recurrence_type_check') then
    alter table public.calendar_events add constraint calendar_events_recurrence_type_check
      check (recurrence_type in ('none','daily','weekly','monthly','yearly'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'calendar_events_recurrence_interval_check') then
    alter table public.calendar_events add constraint calendar_events_recurrence_interval_check
      check (recurrence_interval between 1 and 999);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'calendar_events_recurrence_until_check') then
    alter table public.calendar_events add constraint calendar_events_recurrence_until_check
      check (recurrence_until is null or recurrence_until >= event_date);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'calendar_events_occasion_repeats_yearly_check') then
    alter table public.calendar_events add constraint calendar_events_occasion_repeats_yearly_check
      check (occasion_type = 'none' or (recurrence_type = 'yearly' and recurrence_interval = 1));
  end if;
end $$;

notify pgrst, 'reload schema';
