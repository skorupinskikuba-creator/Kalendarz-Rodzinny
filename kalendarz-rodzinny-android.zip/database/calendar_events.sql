-- Kalendarz Rodzinny — samodzielny schemat dla NOWEGO projektu Supabase.
-- Uruchom tylko w projekcie Kalendarz Rodzinny. Nie wymaga i nie modyfikuje
-- projektu Zakupy Razem.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.households (
  id uuid primary key default extensions.gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  owner_id uuid not null references auth.users(id) on delete cascade,
  invite_hash text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.household_members (
  household_id uuid not null references public.households(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 60),
  role text not null check (role in ('owner','member')),
  joined_at timestamptz not null default now(),
  primary key (household_id, user_id)
);

create unique index if not exists one_calendar_household_per_user
  on public.household_members(user_id);

create table if not exists public.calendar_events (
  id uuid primary key default extensions.gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 100),
  event_date date not null,
  event_time time,
  notes text not null default '' check (char_length(notes) <= 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_calendar_events_household_date
  on public.calendar_events(household_id, event_date, event_time);

create or replace function public.is_household_member(p_household uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.household_members m
    where m.household_id = p_household and m.user_id = (select auth.uid())
  );
$$;

create or replace function public.is_household_owner(p_household uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.households h
    where h.id = p_household and h.owner_id = (select auth.uid())
  );
$$;

create or replace function public.create_household(p_name text, p_display_name text)
returns jsonb
language plpgsql security definer set search_path = ''
as $$
declare
  gid uuid;
  code text;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if exists (select 1 from public.household_members where user_id = auth.uid()) then
    raise exception 'Already a member';
  end if;
  if nullif(trim(coalesce(p_name, '')), '') is null then
    raise exception 'Name required';
  end if;
  code := encode(extensions.gen_random_bytes(24), 'hex');
  insert into public.households(name, owner_id, invite_hash)
  values (
    left(trim(p_name), 60), auth.uid(),
    encode(extensions.digest(code, 'sha256'), 'hex')
  ) returning id into gid;
  insert into public.household_members(household_id, user_id, display_name, role)
  values (
    gid, auth.uid(),
    left(coalesce(nullif(trim(p_display_name), ''), 'Domownik'), 60),
    'owner'
  );
  return jsonb_build_object('household_id', gid, 'invite_code', code);
end;
$$;

create or replace function public.join_household(p_invite_code text, p_display_name text)
returns uuid
language plpgsql security definer set search_path = ''
as $$
declare
  gid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if exists (select 1 from public.household_members where user_id = auth.uid()) then
    raise exception 'Already a member';
  end if;
  select id into gid from public.households
  where invite_hash = encode(
    extensions.digest(coalesce(trim(p_invite_code), ''), 'sha256'), 'hex'
  );
  if gid is null then raise exception 'Invite code invalid or expired'; end if;
  insert into public.household_members(household_id, user_id, display_name, role)
  values (
    gid, auth.uid(),
    left(coalesce(nullif(trim(p_display_name), ''), 'Domownik'), 60),
    'member'
  );
  return gid;
end;
$$;

create or replace function public.rotate_household_invite(p_household_id uuid)
returns text
language plpgsql security definer set search_path = ''
as $$
declare
  code text;
begin
  if not public.is_household_owner(p_household_id) then
    raise exception 'Only owner';
  end if;
  code := encode(extensions.gen_random_bytes(24), 'hex');
  update public.households
  set invite_hash = encode(extensions.digest(code, 'sha256'), 'hex')
  where id = p_household_id;
  return code;
end;
$$;

alter table public.households enable row level security;
alter table public.household_members enable row level security;
alter table public.calendar_events enable row level security;

drop policy if exists "Calendar members can view household" on public.households;
create policy "Calendar members can view household"
  on public.households for select to authenticated
  using (public.is_household_member(id));

drop policy if exists "Calendar members can view members" on public.household_members;
create policy "Calendar members can view members"
  on public.household_members for select to authenticated
  using (public.is_household_member(household_id));

drop policy if exists "Calendar members can read events" on public.calendar_events;
create policy "Calendar members can read events"
  on public.calendar_events for select to authenticated
  using (public.is_household_member(household_id));

drop policy if exists "Calendar members can add events" on public.calendar_events;
create policy "Calendar members can add events"
  on public.calendar_events for insert to authenticated
  with check (
    public.is_household_member(household_id)
    and created_by = (select auth.uid())
  );

drop policy if exists "Calendar members can edit events" on public.calendar_events;
create policy "Calendar members can edit events"
  on public.calendar_events for update to authenticated
  using (public.is_household_member(household_id))
  with check (public.is_household_member(household_id));

drop policy if exists "Calendar members can delete events" on public.calendar_events;
create policy "Calendar members can delete events"
  on public.calendar_events for delete to authenticated
  using (public.is_household_member(household_id));

revoke all on function public.is_household_member(uuid), public.is_household_owner(uuid),
  public.create_household(text, text), public.join_household(text, text),
  public.rotate_household_invite(uuid) from public;
grant execute on function public.is_household_member(uuid), public.is_household_owner(uuid),
  public.create_household(text, text), public.join_household(text, text),
  public.rotate_household_invite(uuid) to authenticated;

grant select on public.households, public.household_members to authenticated;
grant select, insert, update, delete on public.calendar_events to authenticated;

-- Enable live event updates in this project's Realtime publication.
do $$ begin
  alter publication supabase_realtime add table public.calendar_events;
exception when duplicate_object then null;
end $$;

notify pgrst, 'reload schema';
