package pl.kalendarzrodzinny;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://" + APP_HOST + "/assets/index.html";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setChrome(false);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 245, 246));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new NativeShareBridge(), "KalendarzNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new LocalAssetsClient());
        setContentView(webView);
        loadStartUrl(getIntent());
    }

    /** Open Google authentication ONLY in the user's external browser, never in WebView. */
    private void loadStartUrl(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        if (uri != null && "kalendarzrodzinny".equalsIgnoreCase(uri.getScheme())
                && "auth".equalsIgnoreCase(uri.getHost())
                && "/callback".equals(uri.getPath())) {
            String code = uri.getQueryParameter("code");
            if (code != null && !code.isEmpty() && code.length() < 4096) {
                webView.loadUrl(APP_URL + "?oauth_code=" + Uri.encode(code));
                return;
            }
        }
        webView.loadUrl(APP_URL);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) loadStartUrl(intent);
    }

    /** Local share/copy bridge plus external authentication launch. */
    private final class NativeShareBridge {
        @JavascriptInterface
        public void setDarkMode(boolean dark) {
            runOnUiThread(() -> setChrome(dark));
        }

        @JavascriptInterface
        public void openLogin(String url) {
            if (url == null || url.length() > 4000) return;
            Uri uri;
            try { uri = Uri.parse(url); } catch (Exception ex) { return; }
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null
                    || !host.matches("[a-zA-Z0-9-]+\\.supabase\\.co")
                    || !"/auth/v1/authorize".equals(uri.getPath())) return;
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception ignored) { }
            });
        }
        @JavascriptInterface
        public void copyText(String text) {
            if (text == null || text.length() > 20000) return;
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Kalendarz Rodzinny", text));
            });
        }

        @JavascriptInterface
        public void shareText(String text) {
            if (text == null || text.length() > 20000) return;
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(send, "Udostępnij Kalendarz Rodzinny")); }
                catch (Exception ignored) { }
            });
        }
    }

    private void setChrome(boolean dark) {
        int light = Color.rgb(244, 246, 248);
        int night = Color.rgb(18, 23, 27);
        getWindow().setStatusBarColor(dark ? night : light);
        getWindow().setNavigationBarColor(dark ? night : Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0
                : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    /** Maps a safe local HTTPS origin to packaged assets without extra libraries. */
    private final class LocalAssetsClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) return false;
            Uri uri = request.getUrl();
            if ("https".equalsIgnoreCase(uri.getScheme()) && APP_HOST.equals(uri.getHost())) return false;
            if ("https".equalsIgnoreCase(uri.getScheme())) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
            }
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || !APP_HOST.equals(uri.getHost())) {
                return super.shouldInterceptRequest(view, request);
            }
            String path = uri.getPath();
            if (path == null || !path.startsWith("/assets/")) {
                return notFound();
            }
            String relativePath = path.substring("/assets/".length());
            if (relativePath.isEmpty() || relativePath.startsWith("/") || relativePath.contains("..")) {
                return notFound();
            }
            try {
                InputStream asset = getAssets().open(relativePath);
                return new WebResourceResponse(mimeType(relativePath), "UTF-8", asset);
            } catch (IOException ignored) {
                return notFound();
            }
        }

        private WebResourceResponse notFound() {
            return new WebResourceResponse("text/plain", "UTF-8",
                    new ByteArrayInputStream("File not found".getBytes()));
        }

        private String mimeType(String file) {
            if (file.endsWith(".html")) return "text/html";
            if (file.endsWith(".js")) return "text/javascript";
            if (file.endsWith(".css")) return "text/css";
            if (file.endsWith(".png")) return "image/png";
            if (file.endsWith(".svg")) return "image/svg+xml";
            if (file.endsWith(".webmanifest")) return "application/manifest+json";
            return "application/octet-stream";
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
