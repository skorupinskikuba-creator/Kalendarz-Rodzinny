# Kalendarz Rodzinny — Android

## Zbuduj testowy APK bez Android Studio

1. Rozpakuj pakiet `Kalendarz_Rodzinny_Android_Pakiet.zip` do repozytorium GitHub. W katalogu głównym powinny być pliki `kalendarz-rodzinny-android.zip` i folder `.github/workflows`.
2. W GitHub otwórz kartę **Actions**, wybierz **Kalendarz Rodzinny — zbuduj APK** i kliknij **Run workflow**. Możesz też uruchomić budowanie przez push.
3. Po zakończeniu pobierz artefakt **Kalendarz-Rodzinny-APK**, rozpakuj go i zainstaluj `app-debug.apk` na telefonach.

## Konfiguracja osobnego projektu Kalendarza Rodzinnego

1. W nowym projekcie Supabase utworzonym dla Kalendarza Rodzinnego otwórz **SQL Editor** i uruchom `database/calendar_events.sql`. Ten plik sam tworzy własne tabele grup, członków, wydarzeń, polityki bezpieczeństwa i funkcje zaproszeń.
2. W tym samym nowym projekcie otwórz **Authentication → URL Configuration → Redirect URLs** i dodaj dokładnie: `kalendarzrodzinny://auth/callback`.
3. Włącz dostawcę **Google** w **Authentication → Sign In / Providers** dla nowego projektu i skonfiguruj jego dane OAuth.
4. Na obu telefonach otwórz ⚙ i wpisz ten sam **Project URL** oraz publiczny klucz **anon/publishable** z nowego projektu Kalendarza Rodzinnego. Nigdy nie używaj `service_role`.
5. Zaloguj się na każdym telefonie osobnym kontem Google. Na pierwszym utwórz grupę i udostępnij wygenerowany kod zaproszenia. Na drugim wklej ten kod, aby dołączyć. Wydarzenia będą się synchronizować na żywo.

To osobna aplikacja, projekt Supabase, grupa i system zaproszeń. Nie wymaga tabel ani danych z „Zakupy Razem”.

## Co zawiera pakiet

- `kalendarz-rodzinny-android.zip` — projekt Android i zasoby aplikacji.
- `.github/workflows/build-calendar-apk.yml` — workflow budujący APK testowe.
- `database/calendar_events.sql` — migracja tabeli wydarzeń współdzielonych.

Do przygotowania APK nie jest wymagane Android Studio. APK z workflow jest wersją debug do testów; nie jest podpisanym pakietem do Google Play.
