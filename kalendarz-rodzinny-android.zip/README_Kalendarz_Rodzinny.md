# Kalendarz Rodzinny — Android

## Zbuduj APK bez Android Studio

1. Rozpakuj pakiet `Kalendarz_Rodzinny_Android_Pakiet.zip` do repozytorium GitHub. W katalogu głównym powinny być pliki `kalendarz-rodzinny-android.zip` i folder `.github/workflows`.
2. W GitHub otwórz kartę **Actions**, wybierz **Kalendarz Rodzinny — zbuduj APK** i kliknij **Run workflow**. Możesz też uruchomić budowanie przez push.
3. Po zakończeniu pobierz artefakt **Kalendarz-Rodzinny-APK** i zainstaluj APK na telefonach. Numer wersji zwiększa się automatycznie przy każdym uruchomieniu workflow.

### Aktualizowanie aplikacji bez odinstalowania

Android zachowa aplikację i jej dane, jeśli kolejny APK ma ten sam identyfikator i jest podpisany tym samym kluczem. Workflow buduje wersję aktualizacyjną, gdy w repozytorium GitHub dodasz sekrety Actions: `KALENDARZ_UPLOAD_KEYSTORE_BASE64`, `KALENDARZ_UPLOAD_STORE_PASSWORD`, `KALENDARZ_UPLOAD_KEY_ALIAS` i `KALENDARZ_UPLOAD_KEY_PASSWORD`. Sekret `KALENDARZ_UPLOAD_KEYSTORE_BASE64` zawiera plik keystore zakodowany jako Base64. Zachowaj kopię keystore i haseł; bez tego klucza nie będzie można podpisywać kolejnych aktualizacji tym samym podpisem.

Jeśli sekrety nie są skonfigurowane, workflow nadal tworzy testowy APK debug, ale jego podpis może nie być stały między uruchomieniami. Pierwsze przejście z wcześniej zainstalowanego APK debug na stały podpis może wymagać jednorazowej reinstalacji. Wydarzenia i członkostwo grupy są przechowywane w Supabase.

## Konfiguracja osobnego projektu Kalendarza Rodzinnego

1. W nowym projekcie Supabase utworzonym dla Kalendarza Rodzinnego otwórz **SQL Editor** i uruchom `database/calendar_events.sql`. Ten plik sam tworzy własne tabele grup, członków, wydarzeń, polityki bezpieczeństwa i funkcje zaproszeń.
   Jeśli projekt kalendarza już działa i uruchomiłeś wcześniejszą wersję SQL, uruchom zamiast tego tylko `database/calendar_recurrence_upgrade.sql`. Doda on obsługę powtarzania, zachowując dotychczasowe wydarzenia.
2. W tym samym nowym projekcie otwórz **Authentication → URL Configuration → Redirect URLs** i dodaj dokładnie: `kalendarzrodzinny://auth/callback`.
3. Włącz dostawcę **Google** w **Authentication → Sign In / Providers** dla nowego projektu i skonfiguruj jego dane OAuth.
4. Na obu telefonach otwórz ⚙ i wpisz ten sam **Project URL** oraz publiczny klucz **anon/publishable** z nowego projektu Kalendarza Rodzinnego. Nigdy nie używaj `service_role`.
5. Zaloguj się na każdym telefonie osobnym kontem Google. Na pierwszym utwórz grupę i udostępnij wygenerowany kod zaproszenia. Na drugim wklej ten kod, aby dołączyć. Wydarzenia będą się synchronizować na żywo.

## Wydarzenia cykliczne

Przy dodawaniu wydarzenia wybierz codziennie, co tydzień, co miesiąc lub co rok; ustaw interwał (np. co 2 albo 3 tygodnie), dni tygodnia dla cyklu tygodniowego i opcjonalną datę zakończenia. Powtarzane wydarzenia są przechowywane jako seria i wyświetlane w widokach tygodnia, miesiąca i roku.

Urodziny i imieniny zapisują się automatycznie jako cykl roczny. W widokach miesiąca i roku ich dni mają dodatkowy znacznik tortu obok trójkąta wydarzenia.

W widoku tygodnia dotknij wydarzenia, aby je edytować lub usunąć. Dla wydarzenia cyklicznego edycja i usunięcie obejmują całą serię. W Ustawieniach → Grupa rodzinna można utworzyć grupę, dołączyć kodem lub wygenerować zaproszenie dla bliskiej osoby.

To osobna aplikacja, projekt Supabase, grupa i system zaproszeń. Nie wymaga tabel ani danych z „Zakupy Razem”.

## Co zawiera pakiet

- `kalendarz-rodzinny-android.zip` — projekt Android i zasoby aplikacji.
- `.github/workflows/build-calendar-apk.yml` — workflow budujący APK testowe.
- `database/calendar_events.sql` — migracja tabeli wydarzeń współdzielonych.
- `database/calendar_recurrence_upgrade.sql` — aktualizacja istniejącej bazy o cykliczność.

Do przygotowania APK nie jest wymagane Android Studio. APK z workflow jest wersją debug do testów; nie jest podpisanym pakietem do Google Play.

W polskim kalendarzu czerwonym kolorem oznaczane są niedziele i dni ustawowo wolne od pracy, w tym święta ruchome i Wigilia 24 grudnia.

Dni ustawowo wolne od pracy i niedziele są oznaczone czerwonym kolorem. Święta ruchome są wyliczane dla każdego roku; lista obejmuje także Wigilię 24 grudnia.
